
var height = 6; //Numero de linhas ou tentativas
var width = 5; //Numero de colunas ou letras. Comprimento da palavra

var row = 0; //Linha e tentativa atual
var col = 0; //Letra atual

var gameOver = false; //Controle de quando o jogo finaliza

var word = "AULAS"; //Palavra teste

//Funcao executada ao abrir o arquivo. "Start" da unity
window.onload = function()
{
    initialize();
}

//Funcao que cria o jogo inicial
function initialize(){
    //Criar o jogo
    for(let r = 0; r < height; r++)
    {
        for (let c = 0; c < width; c++)
        {
            let tile = document.createElement("span"); //Criar um elemento para configurar a "caixa" da letra
            tile.id = "jogo-" + r.toString() + "-" + c.toString(); //Adicionar um id para localizar este elemento no padrao jogo-linha-coluna
            tile.classList.add("tile"); //Adicionar a classe "tile"
            tile.innerText = ""; //Adicionar um texto vazio para poder receber uma letra

            document.getElementById("jogo").appendChild(tile);
        }
    }

    //Receber uma letra
    document.addEventListener("keyup", (e) => 
    {
        if (gameOver) return; //Verificar se o jogo ja finalizou para nao receber mais nenhum comando

        //alert(e.code); //Proposito de teste 

        if ("KeyA" <= e.code && e.code <= "KeyZ")
        {
            //Verificar se esta numa posicao que ainda pode receber letra
            if (col < width)
            {
                let currTile = document.getElementById("jogo-" + row.toString() + "-" + col.toString());
                if (currTile.innerText == "")
                {
                    currTile.innerText = e.code[3]; //Pegar somente a letra "A" de KeyA(0123)
                }

                col += 1; //Avancar uma coluna
            }
        }
        else if (e.code == "Backspace"){
            if (0 < col && col <= width)
            {
                col -= 1; //Voltar uma coluna

                let currTile = document.getElementById("jogo-" + row.toString() + "-" + col.toString());
                currTile.innerText = ""; //Esvaziar a letra
            }
        }
        else if (e.code == "Enter")
        {
            update();
            row += 1;
            col = 0;
        }

        if (!gameOver && row == height) //Se o jogo nao finalizou
        {
            gameOver = true;
            document.getElementById("resposta").innerText = word; //Pegar a palavra dita como resposta
        }
    }

    ) //Ainda no evento
}

function update()
{
    let correto = 0;
    for (let c = 0; c < width; c++)
    {
        let currTile = document.getElementById("jogo-" + row.toString() + "-" + c.toString());

        let letter = currTile.innerText;

        if (word[c] == letter) //Se a letra estiver correta e no lugar correto
        {
            currTile.classList.add("correto");
            correto += 1;
        }
        else if (word.includes(letter)) //Se a letra estiver correta mas no lugar errado
        {
            currTile.classList.add("contem");
        }
        else //Se a letra estiver errada
        {
            currTile.classList.add("errado");
        }

        if (correto == width)
        {
            gameOver = true;
            document.getElementById("resposta").innerText = word;
        }
    }
}